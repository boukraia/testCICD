package projetarchitecture.projetarchitecture;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetarchitectureApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetarchitectureApplication.class, args);
	}

}
