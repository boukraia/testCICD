package projetarchitecture.projetarchitecture.util;

public interface Validator<T> {
    void validate(T object);
}
