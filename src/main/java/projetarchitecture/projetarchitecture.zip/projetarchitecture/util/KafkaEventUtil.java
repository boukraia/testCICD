package projetarchitecture.projetarchitecture.util;

public class KafkaEventUtil {
}
