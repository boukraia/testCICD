package projetarchitecture.projetarchitecture.util;

import projetarchitecture.projetarchitecture.model.Account;

public interface AccountValidator {
    void validate(Account account);
}
