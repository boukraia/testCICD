package projetarchitecture.projetarchitecture.util;

import projetarchitecture.projetarchitecture.model.Client;

public interface ClientValidator {
    void validate(Client client);
}
