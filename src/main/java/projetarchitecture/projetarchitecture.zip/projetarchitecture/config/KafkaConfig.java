package projetarchitecture.projetarchitecture.config;

public class KafkaConfig {
}
