package projetarchitecture.projetarchitecture.config;

public class MongoDBConfig {
}
