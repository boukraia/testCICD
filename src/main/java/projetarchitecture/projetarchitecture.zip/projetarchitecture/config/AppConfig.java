package projetarchitecture.projetarchitecture.config;

public class AppConfig {
}
